<?php
/**
 * ReMe Autoloader
 *
 * Author:          Andrei Baicus <andrei@themeisle.com>
 * Created on:      17/08/2018
 *
 * @package ReMe
 */

namespace ReMe;

/**
 * Class Autoloader
 *
 * @package ReMe
 */
class Autoloader {
	/**
	 * An associative array where the key is a namespace prefix and the value
	 * is an array of base directories for classes in that namespace.
	 *
	 * @var array
	 */
	protected $prefixes = array();

	/**
	 * Register loader with SPL autoloader stack.
	 *
	 * @return void
	 */
	public function register() {
		spl_autoload_register( array( $this, 'load_class' ) );
	}

	/**
	 * Adds a base directory for a namespace prefix.
	 *
	 * @param string $prefix   The namespace prefix.
	 * @param string $base_dir A base directory for class files in the
	 *                         namespace.
	 * @param bool   $prepend  If true, prepend the base directory to the stack
	 *                         instead of appending it; this causes it to be searched first rather
	 *                         than last.
	 *
	 * @return void
	 */
	public function add_namespace( $prefix, $base_dir, $prepend = false ) {
		// normalize namespace prefix
		$prefix = trim( $prefix, '\\' ) . '\\';

		// normalize the base directory with a trailing separator
		$base_dir = rtrim( $base_dir, DIRECTORY_SEPARATOR ) . '/';

		// initialize the namespace prefix array
		if ( isset( $this->prefixes[ $prefix ] ) === false ) {
			$this->prefixes[ $prefix ] = array();
		}

		// retain the base directory for the namespace prefix
		if ( $prepend ) {
			array_unshift( $this->prefixes[ $prefix ], $base_dir );
		} else {
			array_push( $this->prefixes[ $prefix ], $base_dir );
		}
	}

	/**
	 * Loads the class file for a given class name.
	 *
	 * @param string $class The fully-qualified class name.
	 *
	 * @return mixed The mapped file name on success, or boolean false on
	 * failure.
	 */
	public function load_class( $class ) {
		// the current namespace prefix
		$prefix = $class;

		// work backwards through the namespace names of the fully-qualified
		// class name to find a mapped file name
		while ( false !== strrpos( $prefix, '\\' ) ) {
			$pos = strrpos( $prefix, '\\' );
			// retain the trailing namespace separator in the prefix
			$prefix = substr( $class, 0, $pos + 1 );

			// the rest is the relative class name
			$relative_class = substr( $class, $pos + 1 );

			// try to load a mapped file for the prefix and relative class
			$mapped_file = $this->load_mapped_file( $prefix, $relative_class );
			if ( $mapped_file ) {
				return $mapped_file;
			}

			// remove the trailing namespace separator for the next iteration
			// of strrpos()
			$prefix = rtrim( $prefix, '\\' );
		}

		// never found a mapped file
		return false;
	}

	/**
	 * Load the mapped file for a namespace prefix and relative class.
	 *
	 * @param string $prefix         The namespace prefix.
	 * @param string $relative_class The relative class name.
	 *
	 * @return mixed Boolean false if no mapped file can be loaded, or the
	 * name of the mapped file that was loaded.
	 */
	protected function load_mapped_file( $prefix, $relative_class ) {
		// are there any base directories for this namespace prefix?
		if ( isset( $this->prefixes[ $prefix ] ) === false ) {
			return false;
		}

		// replace the namespace prefix with the base directory,
		// replace namespace separators with directory separators
		// in the relative class name, append with .php
		$class         = $prefix . $relative_class;
		$relative_path = strtolower( str_replace( '\\', '/', $relative_class ) );

		// look through base directories for this namespace prefix
		foreach ( $this->prefixes[ $prefix ] as $base_dir ) {
			$file = $base_dir . $relative_path . '.php';

			// if the mapped file exists, require it
			if ( $this->require_file( $file, $class ) ) {
				// yes, we're done
				return $file;
			}
		}

		// never found it
		return false;
	}

	/**
	 * If a file exists, require it from the file system.
	 *
	 * @param string $file  The file to require.
	 * @param string $class The fully-qualified name being loaded.
	 *
	 * @return bool True if the file was readable and required, false if not.
	 */
	protected function require_file( $file, $class ) {
		if ( $this->is_declared( $class ) ) {
			return true;
		}

		if ( ! is_file( $file ) || ! is_readable( $file ) ) {
			return false;
		}

		include_once $file;

		return $this->is_declared( $class );
	}

	/**
	 * Check if a class, interface or trait is declared.
	 *
	 * @param string $class The fully-qualified name.
	 *
	 * @return bool
	 */
	protected function is_declared( $class ) {
		return class_exists( $class, false )
			|| interface_exists( $class, false )
			|| trait_exists( $class, false );
	}
}
