<?php
/**
 * Template used for component rendering wrapper.
 *
 * Name:    Header Footer Grid
 *
 * @version 1.0.0
 * @package HFG
 */
namespace HFG;

use HFG\Core\Components\SecondNav;
use HFG\Core\Builder\Header as HeaderBuilder;

$style             = component_setting( SecondNav::STYLE_ID );
$device_class      = isset( $args ) && ! empty( $args ) ? $args['device'] : '';
$container_classes = [ 'nav-menu-secondary' ];

if ( $style !== 'style-plain' ) {
	$container_classes[] = $style;
	$container_classes[] = 'm-style';
}
$menu_id = SecondNav::COMPONENT_ID . '-' . $device_class . '-' . current_row( HeaderBuilder::BUILDER_NAME );

// Desktop and mobile rows both render this landmark; duplicated landmarks
// need unique accessible names.
$device_label   = $device_class === 'mobile' ? __( 'Mobile', 'reme' ) : __( 'Desktop', 'reme' );
$landmark_label = __( 'Secondary Menu', 'reme' ) . ' (' . $device_label . ')';
?>
<div class="rm-top-bar">
	<div role="navigation" class="menu-content <?php echo esc_attr( join( ' ', $container_classes ) ); ?>"
		aria-label="<?php echo esc_attr( $landmark_label ); ?>">
		<?php
		wp_nav_menu(
			array(
				'theme_location' => 'top-bar',
				'menu_class'     => 'nav-ul',
				'menu_id'        => $menu_id,
				'container'      => 'ul',
				'depth'          => - 1,
				'fallback_cb'    => '__return_false',
				'before'         => '<div class="wrap">',
				'after'          => '</div>',
				'walker'         => class_exists( '\ReMe\Views\Secondary_Nav_Walker' ) ? '\ReMe\Views\Secondary_Nav_Walker' : '',
			)
		);
		?>
	</div>
</div>

