<?php
/**
 * Color Control. Handles data passing from args to JS.
 *
 * @package ReMe\Customizer\Controls\React
 */

namespace ReMe\Customizer\Controls\React;

/**
 * Class Button_Appearance
 *
 * @package ReMe\Customizer\Controls\React
 */
class Conditional_Selector extends \WP_Customize_Control {
	/**
	 * Control type.
	 *
	 * @var string
	 */
	public $type = 'reme_context_conditional_selector';
	/**
	 * Additional arguments passed to JS.
	 *
	 * @var string
	 */
	public $default = '';
	/**
	 * Send to JS.
	 */
	public function json() {
		$json            = parent::json();
		$json['default'] = $this->default;
		return $json;
	}

	/**
	 * This method overrides the default render
	 * so that nothing is rendered.
	 * Previously it would try to put an input element where the value was `esc_attr()`
	 * This would trigger notices in PHP
	 * It is not required to have a render as it is being handled by React.
	 */
	final public function render_content() {
		// this is rendered from React
	}
}
