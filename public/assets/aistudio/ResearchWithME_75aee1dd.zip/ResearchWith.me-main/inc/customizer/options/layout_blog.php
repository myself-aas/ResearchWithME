<?php
/**
 * Blog layout section.
 *
 * Author:          Andrei Baicus <andrei@themeisle.com>
 * Created on:      20/08/2018
 *
 * @package ReMe\Customizer\Options
 */

namespace ReMe\Customizer\Options;

use ReMe\Core\Settings\Config;
use ReMe\Core\Settings\Mods;
use ReMe\Customizer\Base_Customizer;
use ReMe\Customizer\Defaults\Layout;
use ReMe\Customizer\Defaults\Utils;
use ReMe\Customizer\Types\Control;
use ReMe\Customizer\Types\Section;

/**
 * Class Layout_Blog
 *
 * @package ReMe\Customizer\Options
 */
class Layout_Blog extends Base_Customizer {
	use Layout;
	use Utils;

	/**
	 * Holds the section name.
	 *
	 * @var string $section
	 */
	private $section = 'reme_blog_archive_layout';

	/**
	 * Function that should be extended to add customizer controls.
	 *
	 * @return void
	 */
	public function add_controls() {
		$this->section_blog();
		$this->add_layout_controls();
		$this->add_post_structure();
		$this->add_post_meta_controls();
		$this->add_featured_post();
		$this->add_design_controls();

	}

	/**
	 * Get the tab slotting for the controls.
	 *
	 * @return array
	 */
	private function get_tabs_slotting() {
		$tab_slotting = [
			'general' => [
				'reme_blog_layout_heading',
				'reme_blog_archive_sidebar_layout',
				'reme_blog_archive_content_width',
				$this->section,
				'reme_grid_layout',
				'reme_archive_hide_title',

				'reme_enable_masonry',
				Config::OPTION_POSTS_PER_PAGE,

				'reme_enable_featured_post',
				'reme_featured_post_target',

				'reme_post_content_ordering',
				'reme_post_excerpt_length',

				'reme_blog_post_meta_fields',

			],
			'style'   => [
				'reme_blog_content_padding',

				'reme_enable_card_style',
				'reme_blog_grid_card_bg_color',
				'reme_blog_grid_text_color',
				'reme_blog_card_shadow',
				'reme_blog_covers_text_color',
				'reme_blog_items_border_radius',

				'reme_archive_typography_post_title_accordion_wrap',
				'reme_archive_typography_post_title',
				'reme_archive_typography_post_excerpt_accordion_wrap',
				'reme_archive_typography_post_excerpt',
				'reme_archive_typography_post_meta_accordion_wrap',
				'reme_archive_typography_post_meta',

			],
		];

		foreach ( $tab_slotting as $tab_key => $tab_data ) {
			$tab_slotting[ $tab_key ] = array_fill_keys( $tab_data, [] );
		}

		return $tab_slotting;
	}


	/**
	 * Add customize section
	 */
	private function section_blog() {
		$this->add_section(
			new Section(
				$this->section,
				array(
					'priority' => 35,
					'title'    => esc_html__( 'Blog / Archive', 'reme' ),
					'panel'    => 'reme_blog',
				)
			)
		);
		$this->add_control(
			new Control(
				$this->section . '_tabs',
				[
					'transport' => 'refresh',
				],
				[
					'priority' => -100,
					'section'  => $this->section,
					'tabs'     => [
						'general' => [
							'label' => __( 'General', 'reme' ),
							'icon'  => 'layout',
						],
						'style'   => [
							'label' => __( 'Design', 'reme' ),
							'icon'  => 'admin-customizer',
						],
					],
					'controls' => $this->get_tabs_slotting(),
				],
				'ReMe\Customizer\Controls\Tabs'
			)
		);
	}


	/**
	 * Add blog layout controls.
	 */
	private function add_layout_controls() {
		$layout_id = 'reme_blog_archive_sidebar_layout';
		$width_id  = 'reme_blog_archive_content_width';

		$this->add_control(
			new Control(
				$layout_id,
				array(
					'sanitize_callback' => array( $this, 'sanitize_sidebar_layout' ),
					'default'           => $this->sidebar_layout_alignment_default( $layout_id ),
				),
				array(
					'label'       => __( 'Sidebar Layout', 'reme' ),
					'section'     => $this->section,
					'priority'    => 10,
					'choices'     => $this->sidebar_layout_choices( $layout_id ),
				),
				'\ReMe\Customizer\Controls\React\Radio_Image'
			)
		);

		$width_default = $this->sidebar_layout_width_default( $width_id );

		$this->add_control(
			new Control(
				$width_id,
				array(
					'sanitize_callback' => 'absint',
					'transport'         => $this->selective_refresh,
					'default'           => $width_default,
				),
				array(
					'label'       => esc_html__( 'Content Width (%)', 'reme' ),
					'section'     => $this->section,
					'type'        => 'reme_range_control',
					'input_attrs' => [
						'min'        => 50,
						'max'        => 100,
						'defaultVal' => $width_default,
					],
					'priority'    => 20,
				),
				'ReMe\Customizer\Controls\React\Range'
			)
		);

		$this->add_control(
			new Control(
				$this->section,
				[
					'default'           => 'grid',
					'sanitize_callback' => [ $this, 'sanitize_blog_layout' ],
				],
				[
					'section'  => $this->section,
					'label'    => esc_html__( 'Post Cards Layout', 'reme' ),
					'priority' => 30,
					'choices'  => [
						'default' => [
							'name'  => __( 'List', 'reme' ),
							'image' => 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAF4AAAB5CAYAAACwe5bgAAAABmJLR0QA/wD/AP+gvaeTAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAB3RJTUUH5AkBDC0qBiacfQAABqdJREFUeNrtXU1T40YQfT2WLS/s4kqR5UAK36jiAKdQ+/8vnOKcIIeEG6RSKZZDcIqwXmA6B0nWSOZjbI00Gqn7YooCWXp601/zZoaYmSHWuCmBQIAX4MUEeAFeTIAX4MUEeAFerAngnde8Or90wwV109+nKoFN7m8nuzwRdZrxkc0ffX8Ebh+AhBS8BCZhSXWAfvwIxIOa3qUl25t+0ZHN8F88Kfw5Z4ApgYY4xZ8cPDTwaZwAvwIAN/MmfIyuyGb4L1mRosCaQIT0BVDFh84cDIGIcHd3B4IGQ7m4/GagRBG2t7f9u5oEfoJmgKAB5RYNbdD64uLCAFx7SbwmkwmOj4/9A68JYKQsT5nodqgXH9q3f9/a2qrd90fwbMxZ0E6sbqa1xfcr/w/XjfRw3TpAKldPo6MVrsa08/Nzb4x15VqGwyGOjo7aDXzZ5vO5N8a6ahvEcdx+xpetTcF105ESRVH7gS+P7qbTSV9mFVwVv1j1OLwJXg5znfaCOCDG11pAgThvFWSvzFFNr5Ff93HxvROMHo1GbwbryO6NUu4WTLAdNVKI89bAL7/OlpWxj65hlVQyY38cxzg9Pa3G+OSiGqxVAjzTMg10honKPd6H0RAcUHnxUjY0Ho9dBVcFUgbTKelUugLfvO+fT7/0o+CyEa0+a+DfRT7sFSd+P/usah9HwKBnNTRVUgvXMVHR0OSH7ypYrQXIymtzcZu6mJaR+XU6TDZb+F974OmNF1A1i08ZYg4+WvP2OllAFdhJrrHXS4Z0XVmwMfBZmkc13oLvBSpNfb96H2zHLv2dh/XN+nIx5A14aoANr4OtvbG+bgJYFVCLJ+D2fnUMJAGxevb42RA0hZKVNAL8tyfgrzmDHVareSEB7IwZ8YCqx/6AmB/ZMzPNPIzWgYvmZPL/+UXm/9yBSXnN4TNBU53MjzZEqvyjMzv/7cK7q2mNoKnph/btWjJBU6+A78Kcaw2Vq5irDEiA91Txts7V+BI0FWsTrvT/URSJoMnHCxBBk8c6wAnwg7RaSlbgGMWTciPvMHU7Imgy7LlUvYIYTABpNxWUrm2Spb2B1trVkCYwpbKOdAEau2gUE0Mt1QvAYrHoBPDvSTzsezWpWyETfGeRLJ/hns1mwQiZ3gqulQVNOfK0bIrRkqAOWM/GXCID4zgRNLmUTTdtDgVNyF0Lce524MrHp4wnETQV7OkZuH/M8ttc+eVC0KQY2BprKFLoz1R3VUGTG74XkqvQ9EyvxaP34hTJvpMtzuPFBHgBXkyAF+DFBHgBXiwQ4LOygj1+d2sq1/8egb/npYqMdLrulSo/7E8/EMaDfjHeqkn2+AzcPmSLT7MupTI2hasCPOHzJ8Z4QN5GWEs3g0O+vrW8J5aDab9kM7jcrq6u0p/87EcGJG3dvb09/8Ani7vzJfWu5lphQJzZ9fW1dzcwmUzaAXyB+TDYX4Nq9eDgwDvwNhMZjQGf4FwD2FRcQD+dTpfZRZcXo1kBrzihO7MGkAYjVy+AV5cR9mH1n/2+kwxQxk3H6a7u09TTJj6+CZvNZsGDGscxTk5OwgK+C7qaIBn/nh6lbfaSDMUmRrVu30kbpW0XTLqTNbQggnA15VF5c3OD0IUPURRhd3c3LB9/eXnZiazGCfCZfr3uEwwYqL1H0hTjnRVQBVk2cXp0hZsQkRxVwQAUDg8PC76yq1XsxkqyJqR2HdierEpWo1/oEOj69q5Jr48Og16J8RC2W6WWr7lKK8Z7YUQXWP1GfLIAvrSFCZc+a3M3UrkWmU+6dkr2oUvcan18z7Oa13oQ9fv+LjNfWdGuHCh4TS8VqH+v0xlYLz57eDZbuIkTcLWb9ocRMKR2+JamBE5WLYP7R+CPr+aaVrc3drQHDON2+JamWhT2Pj47x5UYrkegeThLX2wtXQ2MPQeYkpXdlc9zLcWQs7OzdMg/p7/r8bGiMDDPkCLkG0tU8qmUdH7K7p3Iv3y4Tn9vFVzvvgG/f63vAY/2gJ24V55G5lwF+Iby5+CCa1OW6+MDBjWKsL+/HxbwbdDHbxqAs8/RaNR+4MtepQ36+E0Lr8xFBnms6HQ6leAq1gbg08KJOV8TtbIYbUNXo9C/LXPWFjTBPFrUAfDmiZmA6ONXmakpb9s6Ps/VNNHHG6YJUMRgIxI62fowdTVmTz80fXytwI+HwP5OcQc+p0MzKg5T45UHG/+D3gwuhMnuTh1VwdkDBVI41ZpOZprGJoYHITyV8LqOQ/adlMpVgBcT4AV4MQFegBcT4AV4MUv7H5eyq+Oq1/5lAAAAAElFTkSuQmCC',
						],
						'covers'  => [
							'name'  => __( 'Covers', 'reme' ),
							'image' => 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAF4AAAB5CAYAAACwe5bgAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAMvSURBVHgB7d1PTxNBGMfxp1JTLH8ExXAg8eDNd+Xr9eaNg8FEQxSpgIVSKBTccdMEaElnO535PYfvJ9lLQ8j0y3ZKuzu7rfuKobgXBgnCixBehPAihBchvAjhRQgvQngRwosQXqQd80PXt2a9gbmws27WWXn82O2d2dG5ubDdNeu+nP9z0eEP++bC5up0+PGdn/F12nHhmWpECC9CeBHCixBehPAihBchvAjhRQgvQngRwosQXoTwIoQXIbwI4UWijkA9tLNWbV3LZv/Ykmx0zPY2LZtvp/URuVSNw4fDbuHwm1fexzfROPxxddD7/Nrc6ldj2/9t2Sxjbw8ahx+N680r7+ObaBx++1W9LSr3KybM8e/WbGGnw3rLrXH4cOrCTsIT619V4S2fMMenjC9MJS7DnwzT5rl+5veH8PsP/tjCBjdWROPww5t68yrM771Lc48PUCKt2HWuy/o3KtVKNYe3W9OPex/fUy0WGGsw1YgQXoTwItHnx3v5fmarO/3mFRYmnBX40BMjfHLuRFSNDn9wYi58bNdP7qGwMMHL+D68iQvPVCNCeBHCixBehPAihBchvAjhRQgvQngRwosQXoTwIoQXIbwI4UUIL0J4kcan8LWrP9VKxj9X6olJ3sc30Tj87rrZ3mvL5vMPS7K1Wh33fGvZfPkpWooTjuh7OV1ulvG97/FNNA5/dFFvXpVaWJCKN1eRxnt8WMqYMseHRQM5z18PS0FT5vjDv2UuHsoeL9J4jw97g5fLyc4SXk2sCMGzovb48IHk6fmKKs99OPIyvk7kHMKKEBGmGhHCixBehPAiUe/BlyOz72fmwvvt6VtBhC/uvvbMhd2NuItsRIUPT6zvZA1UWHYz6zEv44u9gAVTjQjhRQgvQngRwosQXoTwIoQXIbwI4UUIL0J4EcKLEF6E8CKEFyG8SPGTVudJXZiQetLqPMtamMAeL8JJqyLs8SLF7wP16yLvVVFT7wP1/xUzsOyK3wcq95NKHV+pS/kWvw/UYGRZpd4H6qrQikHuAyXCm6sICxNE2ONFCC9CeBHCixBehPAihBchvAjhRQgvQniR8O3kJ0Nx/wAXONq4kNEpFQAAAABJRU5ErkJggg==',
						],
						'grid'    => [
							'name'  => __( 'Grid', 'reme' ),
							'image' => 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAgEASABIAAD/2wBDAAEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQH/2wBDAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQH/wAARCAB5AF4DAREAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD+/igAoAKACgAoAKACgAoAKACgAoAKACgD5d8deO/FuleLNZ0/T9ZmtrO2nhWCBYLN1jVrS3kYBpLd3OXdm+Zj1x0wK/XOHuHsmxmTYHE4nA06terTm6lR1K6cmq1SKbUasYq0YpaJbH5vnWdZphc0xdChi506VOcFCChSainSpyesqbe7b1b3OS/4WZ45/wChguP/AAGsP/kSvZ/1U4f/AOhbS/8ABuI/+XHlf6xZ1/0HVP8AwXQ/+VB/wszxz/0MFx/4DWH/AMiUf6qcP/8AQtpf+DcR/wDLg/1izr/oOqf+C6H/AMqPR/GfjLxLpvhrwDfWOqy291q+l3U+ozLDasbqWOHSmR2WSB0Qq1xMcRqg+c5BwMfL5FkeVYrNeI8PiMHCpRwWLo08LBzrJUoSnjFKKcaik7qnBe+5P3d97/QZvm2Y4fLsjrUcTKFXFYarPETUabdSUYYZptSg0rOpPSKS120VvOP+FmeOf+hguP8AwGsP/kSvqP8AVTh//oW0v/BuI/8Alx8//rFnX/QdU/8ABdD/AOVB/wALM8c/9DBcf+A1h/8AIlH+qnD/AP0LaX/g3Ef/AC4P9Ys6/wCg6p/4Lof/ACo9H0Dxl4lu/AXjDVrnVZZdR06axWyuTDahoFllgWQKiwLG24OwO9G68Y4r5fMsjyqjxFkmCpYOEMNiqeIdekp1WqjhCo4tt1HNWcV8MlsfQYHNsxq5HmuKqYmUsRh50VRqOFNOClKmpWSgou6b+JPc84/4WZ45/wChguP/AAGsP/kSvqP9VOH/APoW0v8AwbiP/lx8/wD6xZ1/0HVP/BdD/wCVB/wszxz/ANDBcf8AgNYf/IlH+qnD/wD0LaX/AINxH/y4P9Ys6/6Dqn/guh/8qO3+HXjfxVrPi7TNO1PWJruynS/MsDw2iK5isLmWPLRW8bjbIisMMMkDORxXgcT5Bk+ByXF4nCYKFGvTlh1CoqlaTip4mlCVlOpKOsZNarroezkGc5ni81w2HxOLnVozVdyg4Ukny0Kko6xhF6SSej6H0xX5SfogUAfF/wAS/wDkePEH/Xzb/wDpDa1+68K/8k/lv/Xqp/6kVj8i4i/5HOO/6+U//TFI4avoTxQoA9b+IP8AyJ/ww/7A17/6T6JXxfDX/I74t/7DqH/pzHn1Oe/8irhz/sErf+kYM8kr7Q+WCgD1rwv/AMkx8e/9fGm/+jravjM3/wCSs4c/69Yr/wBIqn1OW/8AJN53/wBfMP8A+l0jyWvsz5YKAPRvhP8A8j3o/wD1z1P/ANNd5Xy/GX/JPY3/AB4T/wBS6B9Bwv8A8jrCf4cR/wCo1U+w6/ET9XCgD5l8ceLP2f8AT/FWsWfi7X7qz8RwTQrqltHYeK5Uila0t3iAksNJuLNt1s0LEwTOoLEEhwyj6PBcVZxgMNSwmGrUo0KKcaalQpzklKUpu8mrv3pPc8TFcPZZjMRUxNelUlVqtObjWnFNqKirRTstIrY5T/hOP2W/+hovP/BZ42/+UddP+uuf/wDP+h/4TUv8jn/1Vyb/AJ81f/B9T/MP+E4/Zb/6Gi8/8Fnjb/5R0f665/8A8/6H/hNS/wAg/wBVcm/581f/AAfU/wAz0Txh4l+Clj4b8CXXijW7i10LUdNupfB06WXiSVrywSLSzcSSJZabPdQlY5tPIXUIreU+YdisyzBODCcR5pgsRjcVh6tKNbMKkauJcqMJKU4Oo04xatBXqz0jpquyOzEZHl+Ko4XD1qdSVPBQlToJVZxcYyUE1Jp3lpThq9dPNnnf/Ccfst/9DRef+Czxt/8AKOu//XXP/wDn/Q/8JqX+Rx/6q5N/z5q/+D6n+Yf8Jx+y3/0NF5/4LPG3/wAo6P8AXXP/APn/AEP/AAmpf5B/qrk3/Pmr/wCD6n+Z6JoPiX4J3HgXxdqOja1cTeD7KayXxNeNZ+JEktpZJIFtAkNxpseoSbpGhBNlbzKM/vCqhscFfiPNMRjcLmFWrSeJwanGhJUaajFTUlLmglyyupPfbodlLI8vo4XEYKnTqKhinF1ourNybg042k3eOsVsed/8Jx+y3/0NF5/4LPG3/wAo67/9dc//AOf9D/wmpf5HH/qrk3/Pmr/4Pqf5h/wnH7Lf/Q0Xn/gs8bf/ACjo/wBdc/8A+f8AQ/8ACal/kH+quTf8+av/AIPqf5na/D7xV8B9T8WabZeCdeub3xJKl8bC2ksfFEKSJHYXMt4TJqWl21muyzSdx5syklcR7pCinkx/E+b5lhamDxVWlKhVcHOMaFOEn7OcakbSirq0op6b7HTg8gy3A4iGJw9OpGrTUlFyqzklzwlCXut2fuyfpufSFfPHtBQB5H4h8KfFm/1m+vPD3xZtdA0aeSNrHR5PAmi6q9ighiSSNtQublJ7nfMssoeRQVEgj6IDQBi/8IR8cv8AouNj/wCG08P/APyXQB69oFpq9ho9haa9q6a9rEERW+1dLCDS0vpTI7CVdPtmeC2CxskeyNiDs3k5Y0Ac5410PxzrP9mf8IX44g8GfZvtv9ped4Z0/wARf2l532T7Ht+3yxfY/sflXWfK3faPtQ348hMgHCf8IR8cv+i42P8A4bTw/wD/ACXQB3vgrRPHGjLqI8Z+N4PGbXDWp05ofDdh4d/s9YhcC6VlsZZRd/ajJbkGXaYPs5CZ81sAG/4is9Z1DRr6z8Paynh7WZ0jFjrEmnQasljIs8TyO2n3TJBciSFZYNsjAJ5vmr8yKKAPI/8AhCPjl/0XGx/8Np4f/wDkugDa8PeFPi1p+s2N54g+LFp4h0eCSQ32jp4E0bSXvo2hlREXULW5ee2MczRz7o1JfyvKb5XY0AeuUAFABQBmT63o1rK8Fzq+mW88ZAkhnv7SGWMkBgHjklV1JUhgGAyCD0Irrp4DHVYRqUsFi6tOWsalPDVpwkk2m4yjBxeqa0e6aOeeMwlOThUxWHpzj8UJ16UZRur6xlJNaNPVbMh/4SPw/wD9B3Rv/BpZf/H6v+zMy/6F2O/8JMR/8rI+v4H/AKDcJ/4UUf8A5MP+Ej8P/wDQd0b/AMGll/8AH6P7MzL/AKF2O/8ACTEf/Kw+v4H/AKDcJ/4UUf8A5MszavpVvHBNcanp8EN0pe1lmvbaKO5RQhZ4JHkVZlAdCWjLAB0JPzDOUMFjKs6kKeExNSdFqNWEKFWc6UndKNSMYNwbcZWUkm+V9maTxWGpxhOeIoQhUTdOU61OMaiVruEnJKaV1dxbWq7orf8ACR+H/wDoO6N/4NLL/wCP1r/ZmZf9C7Hf+EmI/wDlZn9fwP8A0G4T/wAKKP8A8mH/AAkfh/8A6Dujf+DSy/8Aj9H9mZl/0Lsd/wCEmI/+Vh9fwP8A0G4T/wAKKP8A8mWY9X0qWCa6i1PT5LW3Ki4uY722eCAsQFE0yymOIsSAodlySMdaylgsZCpCjPCYmFWrd06UqFWNSolvyQcFKdrO/Kna2ppHFYaUJ1I4mhKnCynUjWpuEL6Lnkpcsb30u1crf8JH4f8A+g7o3/g0sv8A4/Wv9mZl/wBC7Hf+EmI/+Vmf1/A/9BuE/wDCij/8mH/CR+H/APoO6N/4NLL/AOP0f2ZmX/Qux3/hJiP/AJWH1/A/9BuE/wDCij/8mT2+taPdzLb2mrabdTvu2QW99azTPtUu22OOVnbaiszYU4VSx4BNZ1cDjqMHUrYPFUqcbc1Srh61OEbtRV5Sgoq8mkrvVtJasuni8LVkoUsTh6k5XtCnWpzk7Jt2jGTbsk27LRJvY0q5ToCgD4v+Jf8AyPHiD/r5t/8A0hta/deFf+Sfy3/r1U/9SKx+RcRf8jnHf9fKf/pikcNX0J4oUAet/EH/AJE/4Yf9ga9/9J9Er4vhr/kd8W/9h1D/ANOY8+pz3/kVcOf9glb/ANIwZ5JX2h8sFAHrXhf/AJJj49/6+NN/9HW1fGZv/wAlZw5/16xX/pFU+py3/km87/6+Yf8A9LpHktfZnywUAejfCf8A5HvR/wDrnqf/AKa7yvl+Mv8Aknsb/jwn/qXQPoOF/wDkdYT/AA4j/wBRqp9h1+In6uFAHxf8S/8AkePEH/Xzb/8ApDa1+68K/wDJP5b/ANeqn/qRWPyLiL/kc47/AK+U/wD0xSOGr6E8UKAPW/iD/wAif8MP+wNe/wDpPolfF8Nf8jvi3/sOof8ApzHn1Oe/8irhz/sErf8ApGDPJK+0PlgoA9a8L/8AJMfHv/Xxpv8A6Otq+Mzf/krOHP8Ar1iv/SKp9Tlv/JN53/18w/8A6XSPJa+zPlgoA9G+E/8AyPej/wDXPU//AE13lfL8Zf8AJPY3/HhP/UugfQcL/wDI6wn+HEf+o1U+w6/ET9XCgDxbxN4p+LFhruoWnh/w14FvdHhkjWxutV8VGw1CaNoInc3Nnj9wwmaRFX+KNUf+KgDC/wCE0+OP/QofDX/wtj/hQBcj8SftATIskPgLwDLG/KyR+LZ3RgCQSrrGVOCCOCeQRQB0viTX/ibp2leGZtI8PeEbjWL20uH8SWeq+Im0+00+8jSyMUOl3DANfRGSW8WWQgGNYoD/AMtaAOO/4TT44/8AQofDX/wtj/hQBYg8VfHu53fZvA/w9uNm3f5HjCWXZuzt3eWjbd21tucZ2nHQ0AdZY6z8Ux4Z12+1nwx4VsPEdq9t/YdhFr0j6VexPJEtw9/fyKptDGrSGMDIdlRf4qAOL/4TT44/9Ch8Nf8Awtj/AIUAPj8YfHWZ1jh8GfDiWRzhY4/Gju7EAkhUVSxIAJ4B4BNAHWeF9X+MN3rVpB4s8IeFNK0J1uPtl9pevz317Cy20rWwitnjVZBLdCGKQkjZE7uOVxQB6vQAUAeX678F/hh4m1a813XfCVnqGrag6SXl5Jd6pG87xwxwIzJBfRRKViijT5I1BCgkEkkgGR/wzz8Gv+hGsP8AwP1r/wCWVAHqWiaJpfhzSrLRNEs0sNK06Iw2VnG8siQRF3kKK80ksrZd3bLyMcsecUAYPi/4eeDfHv8AZ/8Awl2hQa1/ZX2v+z/PnvYPs3277N9r2/Y7m33ed9jtt3mb9vlDZty24A4v/hnn4Nf9CNYf+B+tf/LKgDtfCPw+8HeA1v08JaHBoq6m1s1+IJ7yf7Q1mJxbFjd3NwV8oXM+0RlAfMO7OBgA29d0LSfE2k3mha7ZJqGk6gkcd5ZyPNGk6RTR3CKzwSRTLtmijf5JFJKgHKkggHl//DPPwa/6Eaw/8D9a/wDllQBr6F8F/hh4Z1az13QvCVnp+rae7yWd5Hd6pI8DyQyQOypPfSxMWilkT542ADEgAgEAHqFABQAUAeW678WNC8P6te6Pd6fq0txYyJHLJbx2bQsXijmBQyXkTkbZFB3Rr8wIGRgn67L+DcwzLB0MbRxOChSxEZShGrKuppRnKD5lChOO8Xa0npbrofN43ifBYHFVsJVoYqVSjJRlKnGk4PmjGa5XKtGW0le8Vrf1Mn/heHhn/oF67/350/8A+WFdv+oGa/8AQXl//geJ/wDmY5f9csu/6Bsb/wCAUP8A5eH/AAvDwz/0C9d/786f/wDLCj/UDNf+gvL/APwPE/8AzMH+uWXf9A2N/wDAKH/y86TWviVo2iaZoGqXNlqcsHiG1lu7RII7UywpClo7LciS7jRXIu4wvlPKMq+SPlz5WB4Wx2YYrMcJSr4SFTLK0KNaVSVZQnKcq0U6TjRlJr9zK/PGD1jo9behi+IcJg8PgcTUo4mUMfTlVpRhGk5QjFUm1UUqsUn+9jblclo9dr83/wALw8M/9AvXf+/On/8Aywr1f9QM1/6C8v8A/A8T/wDMx5/+uWXf9A2N/wDAKH/y8P8AheHhn/oF67/350//AOWFH+oGa/8AQXl//geJ/wDmYP8AXLLv+gbG/wDgFD/5edHp/wAStG1HQNY8Qw2WppaaK8EdzDIlqLiU3DxopgVbp4iAZAW8yWPocZry8TwrjsLmOByydfCSrY+NSVKcJVnSgqak37Ruipq/K7csJdLnfQ4hwmIwOLx8KOIVLByhGpCUaXtJObilyJVXF25lfmlHqc5/wvDwz/0C9d/786f/APLCvU/1AzX/AKC8v/8AA8T/APMxwf65Zd/0DY3/AMAof/Lw/wCF4eGf+gXrv/fnT/8A5YUf6gZr/wBBeX/+B4n/AOZg/wBcsu/6Bsb/AOAUP/l5ueHPiloniXV7bRrKx1WC4ulnZJLqO0WFRb28tw+4xXkr5KRMq4Q/MRnAyR5+acI4/KsFVx1fEYOpSoumpRpSrOo/aVIUlZToQjo5pu8lona70OzAcS4PMcVTwlGjioVKqm4yqRpKC9nTlUd3GrKWqi0rRettlqemV8ofRBQB8X/Ev/kePEH/AF82/wD6Q2tfuvCv/JP5b/16qf8AqRWPyLiL/kc47/r5T/8ATFI4avoTxQoA9b+IP/In/DD/ALA17/6T6JXxfDX/ACO+Lf8AsOof+nMefU57/wAirhz/ALBK3/pGDPJK+0PlgoA9a8L/APJMfHv/AF8ab/6Otq+Mzf8A5Kzhz/r1iv8A0iqfU5b/AMk3nf8A18w//pdI8lr7M+WCgD0b4T/8j3o//XPU/wD013lfL8Zf8k9jf8eE/wDUugfQcL/8jrCf4cR/6jVT7Dr8RP1cKAPnDxn8MvFOt+J9W1WwhsmtLyaJ4WlvEjcqlrBE25CpKnfG3Hpg96/Uci4ryjL8pwWDxE66rUITjUUKEpRvKrUmrST192SPz/N+HcyxuY4rE0I0XSqzg4OVVRlZUoRd1bTWLOX/AOFO+NP+eGn/APgfH/8AE163+u+Q/wDPzE/+E0v8zzf9U83/AJMP/wCD1/kH/CnfGn/PDT//AAPj/wDiaP8AXfIf+fmJ/wDCaX+Yf6p5v/Jh/wDwev8AI7/xb8P/ABFrHh7wTptlFaNc6Fp1zbagJLpI0WWWLTUQROVIlXday5IxjC/3q+cybiTLMFmef4qvOsqWYYqlVwzjRcpOEJ4qT54p+47VoaPz7Hu5pkWPxeAyfD0Y0nUwWHqU66lUUUpSjh0uV295Xpy19O5wH/CnfGn/ADw0/wD8D4//AImvo/8AXfIf+fmJ/wDCaX+Z4X+qeb/yYf8A8Hr/ACD/AIU740/54af/AOB8f/xNH+u+Q/8APzE/+E0v8w/1Tzf+TD/+D1/kd/ofw/8AEdh4J8VaFcRWgv8AV5rN7NVukaJlgkhaTzJQuI+EbGQc8etfOZhxJlmIz7J8wpzrPDYKFeNdui1NOpGoo8sL3lrJXtse5g8ix9DJ8zwU40vb4qdKVJKqnFqEoOXNK3u6RZwH/CnfGn/PDT//AAPj/wDia+j/ANd8h/5+Yn/wml/meH/qnm/8mH/8Hr/IP+FO+NP+eGn/APgfH/8AE0f675D/AM/MT/4TS/zD/VPN/wCTD/8Ag9f5HY+Avhv4m8PeKdP1bUYrNbO2S9WVortJZAZ7G4gjwgUE5kkUH0GT2rxOIuKMpzLKMTg8LOu69WVBwU6MoR/d4ilUleTdl7sXbu9D1sk4fzHAZlQxWIjRVKmqyk4VVKXv0akI2jbX3pK/lqfQ1fmZ94FAHyN8Q7yzi8Z67G/iD9pezdbiDdbeCYJJPC0RNlbHGjsIGBhOd0uGOLppx2oA4v8AtCx/6Gn9sH/wFl/+R6APX/D/AMK7jxDo1hrUHxZ+PenRahEZo7LWPEiWGp26iR49t3Ztp7tBIdm8IWJMbI38WKAJfinbRaDpXgnS7rxJ8cHeytNTtRqXw9Y32paobdNJRrnxbcRwYluj8rWMuyPzXl1NgvUAA8b/ALQsf+hp/bB/8BZf/kegDvfBXg7/AIThdRez+JH7SmhjTWtVk/4SjU/7FNybsXBX7EJbGX7SIfs5+0EbfK82DOfMGAD0jUPCTeC/AfiqG68a/FjxCt19juP7RtdTGr+MtPCXNtH5Xhxo7WExiViDdR7H3W5uGyBQB89f2hY/9DT+2D/4Cy//ACPQBteHbS38SazY6Jb+Nv2rtOmv5JI0vdZd9P0yAxwyzlru8e0dYEYRFEYqd0rRp/FmgD3zwx8L7rw3rVprEnxL+JniJLVbhTpHiPxHHqGkXP2i2ltwbm1WxhMjQGUXEBEi7LiKJ+QuCAer0AFABQAUAFABQAUAFABQAUAFABQAUAFABQAUAFABQAUAFABQAUAFABQAUAD/2Q==',
						],
					],
				],
				'\ReMe\Customizer\Controls\React\Radio_Image'
			)
		);

		$grid_layout_default = '{"desktop":3,"tablet":2,"mobile":1}';

		$this->add_control(
			new Control(
				'reme_grid_layout',
				array(
					'sanitize_callback' => 'reme_sanitize_range_value',
					'default'           => $grid_layout_default,
				),
				array(
					'label'           => esc_html__( 'Columns', 'reme' ),
					'section'         => $this->section,
					'units'           => array(
						'items',
					),
					'input_attrs'     => [
						'min'        => 1,
						'max'        => 4,
						'defaultVal' => json_decode( $grid_layout_default, true ),
					],
					'priority'        => 50,
					'active_callback' => array( $this, 'is_column_layout' ),
				),
				'ReMe\Customizer\Controls\React\Responsive_Range'
			)
		);

		$posts_per_page = get_option( Config::OPTION_POSTS_PER_PAGE );

		$this->wpc->add_setting(
			Config::OPTION_POSTS_PER_PAGE,
			[
				'type'              => 'option',
				'sanitize_callback' => 'absint',
				'default'           => absint( $posts_per_page ),
			]
		);

		$this->wpc->add_control(
			new \ReMe\Customizer\Controls\React\Range(
				$this->wpc,
				Config::OPTION_POSTS_PER_PAGE,
				[
					'type'        => 'reme_range_control',
					'priority'    => 52,
					'section'     => $this->section,
					'label'       => esc_html__( 'Posts per Page', 'reme' ),
					'input_attrs' => [
						'min'        => 1,
						'max'        => 100,
						'defaultVal' => absint( $posts_per_page ),
					],
					'setting'     => Config::OPTION_POSTS_PER_PAGE,
					'default'     => absint( $posts_per_page ),
				]
			)
		);

		$this->add_control(
			new Control(
				'reme_archive_hide_title',
				[
					'sanitize_callback' => 'reme_sanitize_checkbox',
					'default'           => $this->get_v4_defaults( 'reme_archive_hide_title', false ),
				],
				[
					'label'           => esc_html__( 'Disable Title', 'reme' ),
					'section'         => $this->section,
					'type'            => 'reme_toggle_control',
					'priority'        => 70,
					'active_callback' => function () {
						return get_option( 'show_on_front' ) !== 'posts';
					},
				],
				'ReMe\Customizer\Controls\Checkbox'
			)
		);

		$this->add_control(
			new Control(
				'reme_enable_masonry',
				array(
					'sanitize_callback' => 'reme_sanitize_checkbox',
					'default'           => false,
				),
				array(
					'type'            => 'reme_toggle_control',
					'priority'        => 55,
					'section'         => $this->section,
					'label'           => esc_html__( 'Enable Masonry', 'reme' ),
					'active_callback' => array( $this, 'should_show_masonry' ),
				)
			)
		);
	}

	/**
	 * Add featured post controls.
	 */
	private function add_featured_post() {
		$this->add_control(
			new Control(
				'reme_enable_featured_post',
				[
					'sanitize_callback' => 'reme_sanitize_checkbox',
					'default'           => false,
				],
				[
					'label'    => esc_html__( 'Enable featured post section', 'reme' ),
					'section'  => $this->section,
					'type'     => 'reme_toggle_control',
					'priority' => 260,
				],
				'ReMe\Customizer\Controls\Checkbox'
			)
		);

		$this->add_control(
			new Control(
				'reme_featured_post_target',
				array(
					'default'           => 'latest',
					'sanitize_callback' => array( $this, 'sanitize_featured_post_target' ),
				),
				array(
					'label'           => esc_html__( 'Featured Post', 'reme' ),
					'section'         => $this->section,
					'priority'        => 270,
					'type'            => 'select',
					'choices'         => [
						'latest' => esc_html__( 'Latest Post', 'reme' ),
						'sticky' => esc_html__( 'Sticky Post', 'reme' ),
					],
					'active_callback' => function () {
						return get_theme_mod( 'reme_enable_featured_post', false );
					},
				)
			)
		);
	}

	/**
	 * Add post structure controls.
	 */
	private function add_post_structure() {
		$order_default_components = array(
			'thumbnail',
			'title-meta',
			'excerpt',
		);


		$ar_choices = [
			'original' => esc_html__( 'Original', 'reme' ),
			'1-1'      => '1:1',
			'4-3'      => '4:3',
			'16-9'     => '16:9',
			'2-1'      => '2:1',
			'4-5'      => '4:5',
			'3-4'      => '3:4',
			'2-3'      => '2:3',
		];

		$excerpt_length_default = $this->get_v4_defaults( 'reme_post_excerpt_length', 25 );

		$components = array(
			'thumbnail'  => [
				'label'    => __( 'Thumbnail', 'reme' ),
				'controls' => [
					'reme_blog_archive_aspect_ratio' => [
						'label'   => esc_html__( 'Image Aspect Ratio', 'reme' ),
						'type'    => 'select',
						'choices' => $ar_choices,
					],
				],
			],
			'title-meta' => [
				'label'    => __( 'Title & Meta', 'reme' ),
				'controls' => [
					'reme_metadata_separator'     => [
						'label'       => esc_html__( 'Meta Separator', 'reme' ),
						'description' => esc_html__( 'For special characters make sure to use Unicode. For example > can be displayed using \003E.', 'reme' ),
						'type'        => 'text',
					],
					'reme_show_last_updated_date' => [
						'label' => esc_html__( 'Show Last Updated Date', 'reme' ),
						'type'  => 'toggle',
					],
					'reme_author_avatar'          => [
						'label' => esc_html__( 'Show Author Avatar', 'reme' ),
						'type'  => 'toggle',
					],
					'reme_author_avatar_size'     => [
						'type'  => 'responsive-range',
						'label' => esc_html__( 'Author Avatar Size', 'reme' ),
					],
				],
			],
			'excerpt'    => [
				'label'    => __( 'Excerpt', 'reme' ),
				'controls' => [
					'reme_post_excerpt_length' => [
						'label' => esc_html__( 'Excerpt Length', 'reme' ),
						'type'  => 'range',
						'attrs' => [
							'min'        => 5,
							'max'        => 300,
							'defaultVal' => $excerpt_length_default,
							'step'       => 5,
						],
					],
				],
			],
		);

		$this->add_control(
			new Control(
				'reme_post_content_ordering',
				array(
					'sanitize_callback' => array( $this, 'sanitize_post_content_ordering' ),
					'default'           => wp_json_encode( $order_default_components ),
				),
				array(
					'label'      => esc_html__( 'Post Content Order', 'reme' ),
					'section'    => $this->section,
					'components' => $components,
					'priority'   => 65,
				),
				'ReMe\Customizer\Controls\React\Ordering'
			)
		);

		$this->add_control(
			new Control(
				'reme_blog_archive_aspect_ratio',
				[
					'default'           => $this->get_v4_defaults( 'reme_blog_archive_aspect_ratio', 'original' ),
					'sanitize_callback' => function( $value ) use ( $ar_choices ) {
						return array_key_exists( $value, $ar_choices ) ? $value : 'original';
					},
				],
				[
					'section'         => $this->section,
					'type'            => 'hidden',
					'active_callback' => function() {
						return get_theme_mod( $this->section, 'grid' ) !== 'default' || get_theme_mod( 'reme_blog_list_image_position', 'left' ) !== 'no';
					},
				]
			)
		);

		$this->add_control(
			new Control(
				'reme_post_excerpt_length',
				array(
					'sanitize_callback' => 'absint',
					'default'           => $excerpt_length_default,
				),
				array(
					'section' => $this->section,
					'type'    => 'hidden',
				)
			)
		);



		$this->add_control(
			new Control(
				'reme_metadata_separator',
				array(
					'sanitize_callback' => 'sanitize_text_field',
					'default'           => esc_html( '/' ),
				),
				array(
					'section' => $this->section,
					'type'    => 'hidden',
				)
			)
		);


		$this->add_control(
			new Control(
				'reme_author_avatar',
				array(
					'sanitize_callback' => 'reme_sanitize_checkbox',
					'default'           => false,
				),
				array(
					'label'   => esc_html__( 'Show Author Avatar', 'reme' ),
					'section' => $this->section,
					'type'    => 'hidden',
				)
			)
		);


		$this->add_control(
			new Control(
				'reme_author_avatar_size',
				array(
					'sanitize_callback' => 'reme_sanitize_range_value',
					'default'           => '{ "mobile": 20, "tablet": 20, "desktop": 20 }',
				),
				array(
					'label'           => esc_html__( 'Avatar Size', 'reme' ),
					'type'            => 'hidden',
					'section'         => $this->section,
					'units'           => array(
						'px',
					),
					'input_attr'      => array(
						'mobile'  => array(
							'min'          => 20,
							'max'          => 50,
							'default'      => 20,
							'default_unit' => 'px',
						),
						'tablet'  => array(
							'min'          => 20,
							'max'          => 50,
							'default'      => 20,
							'default_unit' => 'px',
						),
						'desktop' => array(
							'min'          => 20,
							'max'          => 50,
							'default'      => 20,
							'default_unit' => 'px',
						),
					),
					'input_attrs'     => [
						'units'      => [ 'px', 'em', 'rem' ],
						'min'        => self::RELATIVE_CSS_UNIT_SUPPORTED_MIN_VALUE,
						'max'        => 50,
						'defaultVal' => [
							'mobile'  => 20,
							'tablet'  => 20,
							'desktop' => 20,
							'suffix'  => [
								'mobile'  => 'px',
								'tablet'  => 'px',
								'desktop' => 'px',
							],
						],
					],
					'priority'        => 170,
					'active_callback' => function () {
						return get_theme_mod( 'reme_author_avatar', false ) && $this->is_meta_enabled();
					},
					'responsive'      => true,
				),
				'ReMe\Customizer\Controls\React\Responsive_Range'
			)
		);

		$this->add_control(
			new Control(
				'reme_show_last_updated_date',
				array(
					'sanitize_callback' => 'reme_sanitize_checkbox',
					'default'           => false,
				),
				array(
					'label'           => esc_html__( 'Use last updated date instead of the published one', 'reme' ),
					'section'         => $this->section,
					'type'            => 'hidden',
					'priority'        => 180,
					'active_callback' => [ $this, 'is_meta_enabled' ],
				)
			)
		);

	}

	/**
	 * Add controls for post meta.
	 */
	private function add_post_meta_controls() {
		$default       = wp_json_encode( [ 'author', 'date', 'comments' ] );
		$default_value = reme_get_default_meta_value( 'reme_post_meta_ordering', $default );
		$this->add_control(
			new Control(
				'reme_blog_post_meta_fields',
				[
					'sanitize_callback' => 'reme_sanitize_meta_repeater',
					'default'           => wp_json_encode( $default_value ),
				],
				[
					'label'            => esc_html__( 'Post Meta Order', 'reme' ),
					'section'          => $this->section,
					'fields'           => [
						'hide_on_mobile' => [
							'type'  => 'checkbox',
							'label' => __( 'Hide on mobile', 'reme' ),
						],
					],
					'components'       => apply_filters(
						'reme_meta_filter',
						array(
							'author'   => __( 'Author', 'reme' ),
							'category' => __( 'Category', 'reme' ),
							'date'     => __( 'Date', 'reme' ),
							'comments' => __( 'Comments', 'reme' ),
						)
					),
					'allow_new_fields' => 'no',
					'priority'         => 65,
					'active_callback'  => [ $this, 'is_meta_enabled' ],
				],
				'\ReMe\Customizer\Controls\React\Repeater'
			)
		);
	}

	/**
	 * Sanitize the container layout value
	 *
	 * @param string $value value from the control.
	 *
	 * @return string
	 */
	public function sanitize_blog_layout( $value ) {
		$allowed_values = array( 'default', 'covers', 'grid' );
		if ( ! in_array( $value, $allowed_values, true ) ) {
			return 'grid';
		}

		return sanitize_text_field( $value );
	}

	/**
	 * Sanitize featured post target
	 *
	 * @param string $value value from the control.
	 *
	 * @return string
	 */
	public function sanitize_featured_post_target( $value ) {
		$allowed_values = [ 'sticky', 'latest' ];
		if ( ! in_array( $value, $allowed_values, true ) ) {
			return 'latest';
		}

		return esc_html( $value );
	}

	/**
	 * Sanitize content order control.
	 */
	public function sanitize_post_content_ordering( $value ) {
		$allowed = array(
			'thumbnail',
			'title-meta',
			'excerpt',
		);

		if ( empty( $value ) ) {
			return wp_json_encode( $allowed );
		}

		$decoded = is_string( $value ) ? json_decode( $value, true ) : $value;

		if ( ! is_array( $decoded ) || empty( $decoded ) ) {
			return wp_json_encode( $allowed );
		}

		foreach ( $decoded as $val ) {
			if ( ! in_array( $val, $allowed, true ) ) {
				return wp_json_encode( $allowed );
			}
		}

		return wp_json_encode( array_values( $decoded ) );
	}

	/**
	 * Checks if the post meta is enabled.
	 *
	 * @return bool
	 */
	public function is_meta_enabled() {
		return in_array( 'title-meta', $this->get_post_elements_order(), true );
	}

	/**
	 * Checks if the excerpt is enabled.
	 *
	 * @return bool
	 */
	public function is_excerpt_enabled() {
		return in_array( 'excerpt', $this->get_post_elements_order(), true );
	}

	/**
	 * Checks if the thumbnail is enabled.
	 *
	 * @return bool
	 */
	public function is_thumbnail_enabled() {
		return in_array( 'thumbnail', $this->get_post_elements_order(), true );
	}

	/**
	 * Get the post elements order.
	 *
	 * @return array
	 */
	private function get_post_elements_order() {
		$default       = array(
			'thumbnail',
			'title-meta',
			'excerpt',
		);
		$content_order = get_theme_mod( 'reme_post_content_ordering', wp_json_encode( $default ) );

		if ( is_string( $content_order ) ) {
			$content_order = json_decode( $content_order, true );
		}

		return is_array( $content_order ) ? $content_order : $default;
	}

	/**
	 * Callback to show grid columns control.
	 *
	 * @return bool
	 */
	public function is_column_layout() {
		$blog_layout = get_theme_mod( $this->section, 'grid' );

		return in_array( $blog_layout, [ 'grid', 'covers' ], true );
	}

	/**
	 * Checks if the layout is covers.
	 *
	 * @return bool
	 */
	public function is_covers_layout() {
		return get_theme_mod( $this->section, 'grid' ) === 'covers';
	}


	/**
	 * Callback to show masonry control.
	 *
	 * @return bool
	 */
	public function should_show_masonry() {
		if ( ! $this->is_column_layout() ) {
			return false;
		}

		$columns = get_theme_mod( 'reme_grid_layout', $this->grid_columns_default() );
		if ( is_string( $columns ) ) {
			$columns = json_decode( $columns, true );
		}

		if ( ! is_array( $columns ) ) {
			return false;
		}

		$columns = array_filter(
			array_values( $columns ),
			function ( $value ) {
				return $value > 1;
			}
		);

		if ( empty( $columns ) ) {
			return false;
		}

		return true;
	}


	/**
	 * Adds design tab controls.
	 */
	private function add_design_controls() {
		$this->add_control(
			new Control(
				'reme_blog_covers_text_color',
				array(
					'sanitize_callback' => 'reme_sanitize_colors',
					'default'           => '#ffffff',
					'transport'         => 'postMessage',
				),
				array(
					'label'                 => esc_html__( 'Text Color', 'reme' ),
					'section'               => $this->section,
					'priority'              => 220,
					'default'               => '#ffffff',
					'active_callback'       => function () {
						return get_theme_mod( $this->section ) === 'covers';
					},
					'live_refresh_selector' => true,
					'live_refresh_css_prop' => [
						'cssVar' => [
							'vars'     => '--color',
							'selector' => '.reme-main',
						],
					],
				),
				'ReMe\Customizer\Controls\React\Color'
			)
		);

		$this->add_control(
			new Control(
				'reme_blog_items_border_radius',
				[
					'sanitize_callback' => 'reme_sanitize_range_value',
					'transport'         => 'postMessage',
					'default'           => $this->get_v4_defaults( 'reme_blog_items_border_radius', 0 ),
				],
				[
					'label'                 => esc_html__( 'Border Radius', 'reme' ),
					'section'               => $this->section,
					'type'                  => 'reme_range_control',
					'input_attrs'           => [
						'min'        => 0,
						'max'        => 100,
						'defaultVal' => $this->get_v4_defaults( 'reme_blog_items_border_radius', 0 ),
					],
					'priority'              => 190,
					'live_refresh_selector' => true,
					'live_refresh_css_prop' => [
						'cssVar'   => [
							'vars'     => '--borderradius',
							'suffix'   => 'px',
							'fallback' => '0',
							'selector' => '.posts-wrapper, .rm-ft-post',
						],
						'fallback' => 0,
						'template' =>
						'body .cover-post, body .layout-grid .article-content-col .content {
							    border-radius: {{value}}px;
					    	}',
					],
				],
				'\ReMe\Customizer\Controls\React\Range'
			)
		);

		$content_padding_default = $this->get_v4_defaults( 'reme_blog_content_padding', $this->blog_archive_card_padding_default() );

		$this->add_control(
			new Control(
				'reme_blog_content_padding',
				array(
					'sanitize_callback' => array( $this, 'sanitize_spacing_array' ),
					'transport'         => 'refresh',
					'default'           => $content_padding_default,
				),
				array(
					'label'       => esc_html__( 'Content Padding', 'reme' ),
					'section'     => $this->section,
					'priority'    => 80,
					'input_attrs' => array(
						'units' => [ 'px', 'em', 'rem' ],
						'min'   => 0,
					),
					'default'     => $content_padding_default,
				),
				'\ReMe\Customizer\Controls\React\Spacing'
			)
		);

		// If this gets enabled, we remove the toggle.
		$this->add_control(
			new Control(
				'reme_enable_card_style',
				array(
					'sanitize_callback' => 'reme_sanitize_checkbox',
					'default'           => $this->get_v4_defaults( 'reme_enable_card_style', false ),
				),
				array(
					'type'     => $this->is_card_style_enabled() ? 'hidden' : 'reme_toggle_control',
					'priority' => 0,
					'section'  => $this->section,
					'label'    => esc_html__( 'Enable Card Style', 'reme' ),
				)
			)
		);


		$card_bg_default = $this->get_v4_defaults( 'reme_blog_grid_card_bg_color', '#333333' );
		$this->add_control(
			new Control(
				'reme_blog_grid_card_bg_color',
				array(
					'sanitize_callback' => 'reme_sanitize_colors',
					'default'           => $card_bg_default,
					'transport'         => 'postMessage',
				),
				array(
					'label'                 => esc_html__( 'Card Background Color', 'reme' ),
					'section'               => $this->section,
					'priority'              => 220,
					'default'               => $card_bg_default,
					'active_callback'       => function () {
						return ( ! $this->is_covers_layout() && $this->is_card_style_enabled() );
					},
					'input_attrs'           => [
						'allow_gradient' => true,
					],
					'live_refresh_selector' => true,
					'live_refresh_css_prop' => [
						'cssVar'   => [
							'vars'     => '--cardbgcolor',
							'selector' => '.posts-wrapper',
						],
						'template' =>
						'.layout-grid .article-content-col .content {
							background: {{value}};
						}',
					],
				),
				'ReMe\Customizer\Controls\React\Color'
			)
		);

		$card_text_default = $this->get_v4_defaults( 'reme_blog_grid_text_color', '#ffffff' );
		$this->add_control(
			new Control(
				'reme_blog_grid_text_color',
				array(
					'sanitize_callback' => 'reme_sanitize_colors',
					'default'           => $card_text_default,
					'transport'         => 'postMessage',
				),
				array(
					'label'                 => esc_html__( 'Text Color', 'reme' ),
					'section'               => $this->section,
					'priority'              => 230,
					'default'               => $card_text_default,
					'active_callback'       => function () {
						return ( ! $this->is_covers_layout() && $this->is_card_style_enabled() );
					},
					'live_refresh_selector' => true,
					'live_refresh_css_prop' => [
						'cssVar'   => [
							'vars'     => '--cardcolor',
							'selector' => '.posts-wrapper',
						],
						'template' =>
						'.layout-grid .article-content-col .content, .layout-grid .article-content-col .content a:not(.button), .layout-grid .article-content-col .content li {
							color: {{value}};
						}',
					],
				),
				'ReMe\Customizer\Controls\React\Color'
			)
		);


		$shadow_default = $this->get_v4_defaults( 'reme_blog_card_shadow', 0 );
		$this->add_control(
			new Control(
				'reme_blog_card_shadow',
				[
					'sanitize_callback' => 'reme_sanitize_range_value',
					'transport'         => 'refresh',
					'default'           => $shadow_default,
				],
				[
					'label'                 => esc_html__( 'Card Box Shadow', 'reme' ),
					'section'               => $this->section,
					'type'                  => 'reme_range_control',
					'input_attrs'           => [
						'min'        => 0,
						'max'        => 5,
						'defaultVal' => $shadow_default,
						'step'       => 0.1,
					],
					'priority'              => 240,
					'active_callback'       => [ $this, 'is_card_style_enabled' ],
					'live_refresh_selector' => true,
					'live_refresh_css_prop' => [
						'fallback' => 0,
						'template' =>
						'body .layout-grid .article-content-col .content {
							    box-shadow: 0 0 calc({{value}}px * 4) 0 rgba(0,0,0,calc(0.1 + 0.{{value}}));
					    	}',
					],
				],
				'\ReMe\Customizer\Controls\React\Range'
			)
		);
	}

	/**
	 * Check if the card style is enabled.
	 *
	 * @return bool
	 */
	public function is_card_style_enabled() {
		$card_style_default = $this->get_v4_defaults( 'reme_enable_card_style', false );
		return Mods::get( 'reme_enable_card_style', $card_style_default ) === true;
	}
}
