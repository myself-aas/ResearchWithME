<?php
/**
 * Generic Tweaks
 *
 * @package ReMe\Views
 */

namespace ReMe\Views;

/**
 * Class Tweaks
 */
class Tweaks extends Base_View {
	/**
	 * Add hooks for the front end.
	 */
	public function init() {
		// Remove gallery default style.
		add_filter( 'use_default_gallery_style', '__return_false' );
		add_filter( 'reme_filter_toggle_content_parts', array( $this, 'filter_global_visibility' ), 200, 2 );
	}

	/**
	 * Hide the header or the footer when they are turned off for the whole site.
	 *
	 * Runs after the post meta filter, because the metabox writes 'off' by default and
	 * that value cannot tell an untouched post from a deliberate one.
	 *
	 * @param bool   $status Whether the part is rendered or not.
	 * @param string $context The part name.
	 *
	 * @return bool
	 */
	public function filter_global_visibility( $status, $context ) {
		if ( $context !== 'header' && $context !== 'footer' ) {
			return $status;
		}

		if ( get_theme_mod( 'reme_disable_' . $context, false ) ) {
			return false;
		}

		return $status;
	}
}
