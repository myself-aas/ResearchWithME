<?php
/**
 * The template for displaying all pages.
 *
 * @package ReMe
 * @since   1.0.0
 */
$container_class = apply_filters( 'reme_container_class_filter', 'container', 'single-page' );

get_header();

$context = 'single-page';
?>
<div class="<?php echo esc_attr( $container_class ); ?> single-page-container">
	<div class="row">
		<?php do_action( 'reme_do_sidebar', $context, 'left' ); ?>
		<div class="rm-single-page-wrap col">
			<?php
			/**
			 * Executes actions before the page header.
			 *
			 * @since 2.4.0
			 */
			do_action( 'reme_before_page_header' );

			/**
			 * Executes the rendering function for the page header.
			 *
			 * @param string $context The displaying location context.
			 *
			 * @since 1.0.7
			 */
			do_action( 'reme_page_header', $context );

			/**
			 * Executes actions before the page content.
			 *
			 * @param string $context The displaying location context.
			 *
			 * @since 1.0.7
			 */
			do_action( 'reme_before_content', $context );

			if ( have_posts() ) {
				while ( have_posts() ) {
					the_post();
					get_template_part( 'template-parts/content', 'page' );
				}
			} else {
				get_template_part( 'template-parts/content', 'none' );
			}

			/**
			 * Executes actions after the page content.
			 *
			 * @param string $context The displaying location context.
			 *
			 * @since 1.0.7
			 */
			do_action( 'reme_after_content', $context );
			?>
		</div>
		<?php do_action( 'reme_do_sidebar', $context, 'right' ); ?>
	</div>
</div>
<?php get_footer(); ?>
