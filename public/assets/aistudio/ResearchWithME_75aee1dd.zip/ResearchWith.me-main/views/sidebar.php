<?php
/**
 * Sidebar view template
 *
 * @package ReMe
 */


?>
<div class="rm-sidebar-wrap col-sm-12 <?php echo esc_attr( $args['wrap_classes'] ); ?>" <?php echo wp_kses_post( $args['data_attrs'] ); ?>>
	<?php echo ( $args['close_button'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
	<aside id="secondary-<?php echo esc_attr( $args['position'] ); ?>" role="complementary" aria-label="<?php echo esc_attr( $args['label'] ); ?>">
		<?php
		/**
		 * Executes actions before the sidebar content.
		 *
		 * @since 2.3.8
		 */
		do_action( 'reme_before_sidebar_content', $args['context'], $args['position'] );
		?>

		<?php
		$has_custom_sidebar = apply_filters( 'reme_has_custom_sidebar', false, $args['context'] );
		if ( ! $has_custom_sidebar ) {
			dynamic_sidebar( $args['slug'] );
		}
		?>

		<?php
		/**
		 * Executes actions after the sidebar content.
		 *
		 * @since 2.3.8
		 */
		do_action( 'reme_after_sidebar_content', $args['context'], $args['position'] );
		?>
	</aside>
</div>
